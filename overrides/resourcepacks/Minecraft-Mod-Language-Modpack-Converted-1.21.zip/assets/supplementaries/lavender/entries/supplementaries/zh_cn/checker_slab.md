```json
{
  "title": "棋盘格台阶",
  "icon": "supplementaries:checker_slab",
  "categories": [
    "minecraft:blocks",
    "minecraft:tag/slabs",
    "minecraft:group/building_blocks"
  ],
  "associated_items": [
    "supplementaries:checker_slab"
  ]
}
```

&spotlight(supplementaries:checker_slab)
**棋盘格台阶**是[棋盘格方块](^supplementaries:checker_block)的[台阶](^minecraft:tag/slabs)变种。

;;;;;

&title(合成)
<recipe;supplementaries:checker_slab>
<recipe;supplementaries:stonecutting/checker_slab>
