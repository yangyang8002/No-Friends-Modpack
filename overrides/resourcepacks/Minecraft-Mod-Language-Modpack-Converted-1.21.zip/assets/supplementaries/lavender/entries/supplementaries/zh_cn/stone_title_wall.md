```json
{
  "title": "石瓦墙",
  "icon": "supplementaries:stone_tile_wall",
  "categories": [
    "minecraft:blocks",
    "minecraft:tag/walls",
    "minecraft:group/building_blocks"
  ],
  "associated_items": [
    "supplementaries:stone_tile_wall"
  ]
}
```

&spotlight(supplementaries:stone_tile_wall)
**石瓦墙**是[石瓦](^supplementaries:stone_tiles)的[墙](^minecraft:tag/walls)变种。

;;;;;

&title(合成)
<recipe;supplementaries:stone_tile_wall>
<recipe;supplementaries:stonecutting/stone_tile_wall_from_bricks>
